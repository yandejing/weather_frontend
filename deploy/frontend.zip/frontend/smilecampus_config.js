window.smilecampus_config = {
  client_id: 'arc52dc98568b1f9',
},
  window.smilecampus_config.modules = {

    weather: {
      module_name: 'demo_template',
      url: window.location.origin + '/demo_platform/home/index.html',
      base_url:'http://localhost:8884',
      page_info: {
        title: '',
        title_img: '',
        logo_title: '',
        logo_img: '',
        home_title: '',
        copyright: ''
      },
      extra: {}
    },
  }

  ;



